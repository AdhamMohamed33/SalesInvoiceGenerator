/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sales.Controller;


import Sales.Model.InvoiceHeader;
import Sales.Model.InvoiceLine;
import Sales.Model.LinesModel;
import Sales.Model.TableModel;
import Sales.View.CreateNewInvoice;
import Sales.View.CreateNewItem;
import Sales.View.SalesInvoiceFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import javax.swing.JComponent;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 *
 * @author galaxy
 */
public class Ctrl implements ActionListener,ListSelectionListener{
     
    private SalesInvoiceFrame frame_out;
    private CreateNewInvoice invoice_dialog;
    private CreateNewItem    lineDialog;
    
    
    
    
    public Ctrl(SalesInvoiceFrame frame_out){
      
       this.frame_out= frame_out;
      
     }
    
     
     @Override
    public void actionPerformed(ActionEvent e) {
     String actionCommand= e.getActionCommand();
     System.out.println(actionCommand);
     switch(actionCommand){
         
         case "Load File":
             loadfile();
             break;
         case "Save File":
             savefile();
             break;
         case "Create New Invoice":
             CreateNewInvoice();
             break;    
         case "Delete invoice":
             deleteInvoice();
             break;
         case "Create New Item":
             createNewItem();
             break;
         case "Delete Item":
             deleteItem();
             break; 
         case"CANCEL":
             createInvoiceCancel();
             break;
         case"OK":
             createInvoiceOK();
                 break;  
         case"CreateLineOK":
                 createLineOK();
                 break;
         case "CreatLineCancel":
             createLineCancel();
             break;
                 }
     
      
     
         }

    @Override
    public void valueChanged(ListSelectionEvent e) {
       int Index_Number=frame_out.getInvoicetable().getSelectedRow();
        System.out.println("No.Row Selected:"+ Index_Number);
        InvoiceHeader currentInvoice= frame_out.getInvoices().get(Index_Number);
        frame_out.getInvoiceNumLabel().setText(""+currentInvoice.getNum());
        frame_out.getInvoiceDateLabel().setText(currentInvoice.getDate());
        frame_out.getCustomerNameLabel().setText(currentInvoice.getCustomer_name());
        frame_out.getInvoiceTotal().setText(""+currentInvoice.getInvoiceTot());
      LinesModel linesmodeltable=new LinesModel(currentInvoice.getLines());
      frame_out.getLinetable().setModel(linesmodeltable);
      linesmodeltable.fireTableDataChanged();
       
    }
   
    
    private void loadfile() {
        JFileChooser f=new JFileChooser();
        try{
       int x= f.showOpenDialog(frame_out);
        if (x== JFileChooser.APPROVE_OPTION){
            File invoice_headerfile = f.getSelectedFile();
            Path header_path =Paths.get(invoice_headerfile.getAbsolutePath());
            List<String> headerLines = Files.readAllLines(header_path); 
            ArrayList<InvoiceHeader> invoicesArray= new ArrayList<>();
            
            for(String headerLine: headerLines){
            String[] h_parts =headerLine.split(",");
            int invoice_num= Integer.parseInt (h_parts[0]);
            String invoice_date= h_parts[1];
            String customer_name= h_parts[2];
            InvoiceHeader invoice=new InvoiceHeader(invoice_num, invoice_date, customer_name);
            invoicesArray.add(invoice);
            } 
               x= f.showOpenDialog(frame_out);
               if(x==JFileChooser.APPROVE_OPTION){
              File invoice_linefile=f.getSelectedFile();
              Path line_path= Paths.get(invoice_linefile.getAbsolutePath());
              List<String> lineOfLines= Files.readAllLines(line_path);
                
                for(String lineLine: lineOfLines){
                  String [] l_parts= lineLine.split(",");
                  int invoice_num=Integer.parseInt(l_parts[0]);
                 String itemName= l_parts[1];
                  double itemPrice=Double.parseDouble(l_parts[2]);
                   int count=Integer.parseInt(l_parts[3]);
                   InvoiceHeader n_inv=null;
              
                   for(InvoiceHeader invoice: invoicesArray){
                   if(invoice.getNum()== invoice_num ){
                   n_inv= invoice;
                   break;
                    }
                }   
                InvoiceLine l=new InvoiceLine(itemName, itemPrice, count, n_inv); 
                 n_inv.getLines().add(l);
              }
           }
           frame_out.setInvoices(invoicesArray);
           TableModel table_model= new TableModel(invoicesArray);
           frame_out.setInvoicestabelemodel(table_model);
           frame_out.getInvoicetable().setModel(table_model);
           frame_out.getInvoicestabelemodel().fireTableDataChanged();
           }
         } catch(IOException e){
               e.printStackTrace();
             }  
    }
 
    private void savefile() {
    }

    private void CreateNewInvoice() {
           invoice_dialog=new CreateNewInvoice(frame_out);
        invoice_dialog.setVisible(true);
          
    }

    private void deleteInvoice() {
        int row=frame_out.getInvoicetable().getSelectedRow();
        if(row!=-1){
        frame_out.getInvoices().remove(row);
        frame_out.getInvoicestabelemodel().fireTableDataChanged();
        
        }
        
    }

    private void createNewItem() {
       CreateNewItem lineDialog = new CreateNewItem(frame_out);
        lineDialog.setVisible(true);
        
        
        
        
        
    }

    private void deleteItem() {
        int x= frame_out.getInvoicetable().getSelectedRow();
        int row=frame_out.getLinetable().getSelectedRow();
        if(x!=-1 && row!=-1){
            InvoiceHeader invoice= frame_out.getInvoices().get(x); 
            invoice.getLines().remove(row);
            LinesModel linestablemodel=new LinesModel(invoice.getLines());
            frame_out.getLinetable().setModel(linestablemodel);
            linestablemodel.fireTableDataChanged();
            
        
        }
      
    }

    private void createInvoiceCancel() {
        invoice_dialog.setVisible(false);
        invoice_dialog.dispose();
        invoice_dialog=null;
        
    }

    private void createInvoiceOK() {
        
        String date= invoice_dialog.getInvDateField().getText();
        String customer=invoice_dialog.getCustNameField().getText();
        int num=frame_out.getNextInvoiceNum();
        InvoiceHeader invoice=new InvoiceHeader(num,date,customer);
         frame_out.getInvoices().add(invoice);
         frame_out.getInvoicestabelemodel().fireTableDataChanged();
    }

    private void createLineOK() {
        
        String it=lineDialog.getItemNameField().getText();
        String coun_string=lineDialog.getItemCountField().getText();
         String price_string=lineDialog.getItemPriceField().getText();
         int count= Integer.parseInt(coun_string);
         double price=Double.parseDouble(price_string);
        lineDialog.setVisible(false);
        lineDialog.dispose();
        lineDialog=null;
    }

    private void createLineCancel() {
        lineDialog.setVisible(false);
        lineDialog.dispose();
        lineDialog=null;
         }

    
    
}
