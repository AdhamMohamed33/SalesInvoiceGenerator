/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sales.Model;

import java.util.ArrayList;

/**
 *
 * @author galaxy
 */
public class InvoiceHeader {
   private int num;
    private String date;
  private  String customer_name;
  private ArrayList<InvoiceLine> lines;
  
    public InvoiceHeader() {
    }

    public InvoiceHeader(int num, String date, String customer_name) {
        this.num = num;
        this.date = date;
        this.customer_name = customer_name;
    }

    public double getInvoiceTot(){
        double total=0.0;
        for(InvoiceLine lines : getLines()){
            
            total+= lines.getInvoiceLineTotal();    
        }
         return total;
    }

    public ArrayList<InvoiceLine> getLines() {
        if(lines==null){ 
            lines=new ArrayList<>();
        }
        return lines;
    }
      
    public int getNum() {
        return num;
    }

    public String getDate() {
        return date;
    }

    public String getCustomer_name() {
        return customer_name;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setCustomer_name(String customer_name) {
        this.customer_name = customer_name;
    }

    @Override
    public String toString() {
        return "InvoiceHeader" + "num=" + num + ", date=" + date + ", customer_name=" + customer_name + '}';
    }
    
    public String getS_Fil(){
    
      return num+","+date+","+customer_name;
    }
    
    
    
}
