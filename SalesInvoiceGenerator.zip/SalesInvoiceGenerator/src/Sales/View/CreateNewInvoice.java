/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sales.View;

import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;
import Sales.Controller.Ctrl;
import java.awt.event.ActionListener;

/**
 *
 * @author galaxy
 */
public class CreateNewInvoice extends JDialog {
private JTextField custNameField;
private JTextField invDateField;
private JLabel  custNameLbl;
private JLabel  invDateLbl;
private JButton okBtn;
private JButton cancelBtn; 

public CreateNewInvoice(CreateNewInvoice frame){
  custNameLbl=new JLabel("Customer Name:");
  custNameField=new  JTextField(30);
  invDateLbl=new JLabel("Invoice Date:");
  invDateField= new    JTextField(30);
   okBtn=new JButton("OK");
   cancelBtn=new JButton("Cancel");
   
   cancelBtn.setActionCommand("CreateInvoiceCancel");
   okBtn.setActionCommand("CreateInvoiceOK");
   
   okBtn.addActionListener(frame.getCtrl());
   cancelBtn.addActionListener(frame.getCtrl());
   setLayout(new GridLayout(3,2));
   add(invDateLbl);
   add(invDateField);
   add(custNameField);
   add(custNameLbl);
   add(okBtn);
  add(cancelBtn);
  pack();
}

    public CreateNewInvoice(SalesInvoiceFrame frame_out) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

  
    

    public JTextField getCustNameField() {
        return custNameField;
    }

    public void setCustNameField(JTextField custNameField) {
        this.custNameField = custNameField;
    }

    public JTextField getInvDateField() {
        return invDateField;
    }

    public void setInvDateField(JTextField invDateField) {
        this.invDateField = invDateField;
    }

    public JLabel getCustNameLbl() {
        return custNameLbl;
    }

    public void setCustNameLbl(JLabel custNameLbl) {
        this.custNameLbl = custNameLbl;
    }

    public JLabel getInvDateLbl() {
        return invDateLbl;
    }

    public void setInvDateLbl(JLabel invDateLbl) {
        this.invDateLbl = invDateLbl;
    }

    public JButton getOkBtn() {
        return okBtn;
    }

    public void setOkBtn(JButton okBtn) {
        this.okBtn = okBtn;
    }

    public JButton getCancelBtn() {
        return cancelBtn;
    }

    public void setCancelBtn(JButton cancelBtn) {
        this.cancelBtn = cancelBtn;
    }

    private ActionListener getCtrl() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


}
