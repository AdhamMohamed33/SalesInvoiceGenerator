/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sales.View;

import Sales.Controller.Ctrl;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author galaxy
 */
public class CreateNewItem extends JDialog {
private JTextField itemNameField;
private JTextField itemPriceField;
private JTextField itemCountField;
private JLabel  itemNameLbl;
private JLabel  itemCountLbl;
private JLabel  itemPriceLbl;
private JButton okBtn;
private JButton cancelBtn; 
    ActionListener getCtrl;

public CreateNewItem(CreateNewItem frame){
  itemNameLbl=new JLabel("Customer Name:");
  itemNameField=new  JTextField(30);
  itemCountLbl=new JLabel("Invoice Date:");
  itemCountField= new JTextField(30);
  itemPriceField= new JTextField(30);
  itemPriceLbl= new    JLabel("Item Price");
   okBtn=new JButton("OK");
   cancelBtn=new JButton("Cancel");
   
   cancelBtn.setActionCommand("CreateInvoiceCancel");
   okBtn.setActionCommand("CreateInvoiceOK");
   
   okBtn.addActionListener(frame.getCtrl());
   cancelBtn.addActionListener(frame.getCtrl());
   
   setLayout(new GridLayout(4,2));
   add(itemPriceField);
   add(itemCountField);
   add(itemNameField);
   add(itemNameLbl);
   add(itemPriceLbl);
   add(itemCountLbl);
   add(okBtn);
  add(cancelBtn);
  pack();
}

    public CreateNewItem(SalesInvoiceFrame frame_out) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    ActionListener getCtrl() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public JTextField getItemNameField() {
        return itemNameField;
    }

    public void setItemNameField(JTextField itemNameField) {
        this.itemNameField = itemNameField;
    }

    public JTextField getItemPriceField() {
        return itemPriceField;
    }

    public void setItemPriceField(JTextField itemPriceField) {
        this.itemPriceField = itemPriceField;
    }

    public JTextField getItemCountField() {
        return itemCountField;
    }

    public void setItemCountField(JTextField itemCountField) {
        this.itemCountField = itemCountField;
    }

    public JLabel getItemNameLbl() {
        return itemNameLbl;
    }

    public void setItemNameLbl(JLabel itemNameLbl) {
        this.itemNameLbl = itemNameLbl;
    }

    public JLabel getItemCountLbl() {
        return itemCountLbl;
    }

    public void setItemCountLbl(JLabel itemCountLbl) {
        this.itemCountLbl = itemCountLbl;
    }

    public JLabel getItemPriceLbl() {
        return itemPriceLbl;
    }

    public void setItemPriceLbl(JLabel itemPriceLbl) {
        this.itemPriceLbl = itemPriceLbl;
    }

    public JButton getOkBtn() {
        return okBtn;
    }

    public void setOkBtn(JButton okBtn) {
        this.okBtn = okBtn;
    }

    public JButton getCancelBtn() {
        return cancelBtn;
    }

    public void setCancelBtn(JButton cancelBtn) {
        this.cancelBtn = cancelBtn;
    }

    public ActionListener getGetCtrl() {
        return getCtrl;
    }

    public void setGetCtrl(ActionListener getCtrl) {
        this.getCtrl = getCtrl;
    }

    
    
}
    

